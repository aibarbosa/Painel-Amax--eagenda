# Painel Amax + eAgenda

O eAgenda continua sendo a agenda oficial. Este servidor consulta a API e entrega ao tablet apenas horário, início/fim e status do agendamento.

## Segurança
- Revogue o token que apareceu no print anterior.
- Gere outro token e mantenha-o somente no servidor.
- Nunca coloque o token no HTML/JavaScript público.
- Não envie o token por chat.

## Rodar
Instale Node.js 18+:
`npm install`
Copie `.env.example` para `.env`, coloque o novo token e rode:
`npm start`
Depois abra `http://localhost:3000`.

Sem token, funciona em modo demonstração.

## Horários
Edite a constante `HOURS` em `public/index.html` para refletir os horários reais da Amax.

O próximo passo é hospedar este servidor e abrir a URL no tablet. Depois podemos adicionar QR Code, tela administrativa e webhook.
