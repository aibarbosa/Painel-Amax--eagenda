const express=require("express"),path=require("path");
const app=express(); app.use(express.json()); app.use(express.static(path.join(__dirname,"public")));
const PORT=process.env.PORT||3000, TOKEN=process.env.EAGENDA_TOKEN, ACCOUNT=process.env.EAGENDA_ACCOUNT_SLUG||"am-studio-barber", AUTH_SCHEME=process.env.EAGENDA_AUTH_SCHEME||"Token";
function dayStart(d){return `${d}T00:00:00-03:00`} function dayEnd(d){return `${d}T23:59:59-03:00`}
async function getAppointments(date){
 if(!TOKEN)return {demo:true,results:[
  {status:"CONFIRMED",start:{dateTime:`${date}T16:00:00-03:00`},end:{dateTime:`${date}T16:30:00-03:00`}},
  {status:"CONFIRMED",start:{dateTime:`${date}T17:30:00-03:00`},end:{dateTime:`${date}T18:30:00-03:00`}}
 ]};
 const u=new URL("https://eagenda.com.br/api/v3/appointments/");
 u.searchParams.set("account_slug",ACCOUNT);u.searchParams.set("start_date",dayStart(date));
 u.searchParams.set("end_date",dayEnd(date));u.searchParams.set("is_cancelled","false");u.searchParams.set("page_size","100");
 const r=await fetch(u,{headers:{accept:"application/json",Authorization:`${AUTH_SCHEME} ${TOKEN}`}});
 if(!r.ok)throw new Error(`eAgenda ${r.status}`);return {demo:false,...await r.json()};
}
app.get("/api/appointments",async(req,res)=>{
 const d=req.query.date;if(!/^\\d{4}-\\d{2}-\\d{2}$/.test(d||""))return res.status(400).json({error:"date inválida"});
 try{const x=await getAppointments(d);res.json({date:d,demo:x.demo,appointments:(x.results||[]).filter(a=>!["CANCELED","CANCELED_CLIENT","CANCELED_GOOGLE"].includes(a.status)).map(a=>({start:a.start?.dateTime,end:a.end?.dateTime,status:a.status})).filter(a=>a.start&&a.end)})}
 catch(e){res.status(502).json({error:"Não foi possível consultar o eAgenda."})}
});
app.listen(PORT, "0.0.0.0", () =>console.log(`Painel Amax: http://localhost:${PORT}`));
